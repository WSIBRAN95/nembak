pkg install python
pkg install git
git clone https://github.com/Bintang73/tembaktembakan.git
python dor.py